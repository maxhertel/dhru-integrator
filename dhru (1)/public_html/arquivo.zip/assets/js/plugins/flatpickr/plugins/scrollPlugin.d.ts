import { Plugin } from "../types/options";
declare function scrollPlugin(): Plugin;
export default scrollPlugin;
