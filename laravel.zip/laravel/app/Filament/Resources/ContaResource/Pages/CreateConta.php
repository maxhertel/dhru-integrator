<?php

namespace App\Filament\Resources\ContaResource\Pages;

use App\Filament\Resources\ContaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateConta extends CreateRecord
{
    protected static string $resource = ContaResource::class;
}
