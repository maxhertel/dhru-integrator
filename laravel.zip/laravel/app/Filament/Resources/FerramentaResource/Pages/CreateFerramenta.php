<?php

namespace App\Filament\Resources\FerramentaResource\Pages;

use App\Filament\Resources\FerramentaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFerramenta extends CreateRecord
{
    protected static string $resource = FerramentaResource::class;
}
