<x-filament-panels::page>
 {{ $this->form }}
</x-filament-panels::page>
